

document.getElementById('search-input').addEventListener('keyup', function () {
    const query = this.value.toLowerCase();
    filterSongs(query);
});

function filterSongs(query) {
    const filteredSongs = songs.filter(song => 
        song.songName.toLowerCase().includes(query) ||
        song.songName.toLowerCase().replace(/<br>/g, '').includes(query) ||
        song.songName.toLowerCase().replace(/<\/?div[^>]*>/g, '').includes(query) 
    );

    updateSearchResults(filteredSongs);
}

function updateSearchResults(filteredSongs) {
    const resultsContainer = document.querySelector('.search_results');
    resultsContainer.innerHTML = '';

    if (filteredSongs.length === 0) {
        resultsContainer.innerHTML = '<p>No songs found</p>';
        return;
    }

    resultsContainer.style.display = 'block';

    filteredSongs.forEach(song => {
        let { id, songName, poster } = song;

        let card = document.createElement('a');
        card.classList.add('card');
        card.href = `#${id}`;
        card.innerHTML = `
            <img src="${poster}" alt="">
            <div class="content">${songName}</div>
        `;

        card.addEventListener('click', () => playSong(id));
        resultsContainer.appendChild(card);
    });
}

function playSong(songId) {
    let song = songs.find(s => s.id === songId);
    if (song) {
        music.src = `audio/${songId}m.mp3`;
        poster_master_play.src = `img/${songId}.jpeg`;
        music.play();
        title.innerHTML = song.songName;
        masterPlay.classList.add('bi-pause-fill');
        masterPlay.classList.remove('bi-play-fill');
        wave.classList.add('active1');
    }
}



function filterSongs(query) {
    const filteredSongs = songs.filter(song => {
        return song.name.toLowerCase().includes(query) || song.artist.toLowerCase().includes(query);
    });
    updateSearchResults(filteredSongs);
}


function updateSearchResults(filteredSongs) {
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = ''; 

    if (filteredSongs.length === 0) {
        resultsContainer.innerHTML = '<p>No songs found</p>'; 
        return;
    }

    filteredSongs.forEach(song => {
        const songCard = document.createElement('div');
        songCard.className = 'song-card';
        songCard.innerHTML = `
            <img src="${song.image}" alt="${song.name}">
            <h5>${song.name}</h5>
            <p>${song.artist}</p>
        `;
        resultsContainer.appendChild(songCard); 
    });
}
const music = new Audio('audio/1m.mp3');
// music.play();

const songs = [{
        id: '1',
        songName: ` Paaro <br>
    <div class="subtitle">Aditya Rikhari</div>`,
        poster: "img/1.jpeg"
    },
    {
        id: '2',
        songName: ` Luther <br>
    <div class="subtitle">Kendrick Lamar</div>`,
        poster: "img/2.jpeg"
    },
    {
        id: "3",
        songName: `I think they call this love <br><div class="subtitle"> Elliot James Reay</div>`,
        poster: "img/3.jpeg",
    },
    {
        id: "4",
        songName: `Baarishein <br><div class="subtitle">Anuv Jain</div>`,
        poster: "img/4.jpeg",
    },
    {
        id: "5",
        songName: `Abhi Na Jao Chhod Kar <br><div class="subtitle">Mohammad Rafi , Asha Bhosle</div>`,
        poster: "img/5.jpeg",
    },
    {
        id: "6",
        songName: `Espresso <br><div class="subtitle">Sabrina Carpenter</div>`,
        poster: "img/6.jpeg",
    },
    {
        id: "7",
        songName: `Not Like Us <br><div class="subtitle">Kendrick Lamar</div>`,
        poster: "img/7.jpeg",
    },
    {
        id: "8",
        songName: `L'amour De Ma Vie <br><div class="subtitle">Billie EIllish</div>`,
        poster: "img/8.jpeg",
    },
    {
        id: "9",
        songName: `Perfect <br><div class="subtitle">One Direction</div>`,
        poster: "img/9.jpeg",
    },
    {
        id: "10",
        songName: `Tu Hai Kahan <br><div class="subtitle">AUR</div>`,
        poster: "img/10.jpeg",
    },
    {
        id: "11",
        songName: `Dope Shope <br><div class="subtitle">Honey Singh</div>`,
        poster: "img/11.jpeg",
    },
    {
        id: "12",
        songName: `Tere Bina <br><div class="subtitle">AR Rahman</div>`,
        poster: "img/12.jpeg",
    },
    {
        id: "13",
        songName: `I Like Me Better <br><div class="subtitle">Lauv</div>`,
        poster: "img/13.jpeg",
    },
    {
        id: "14",
        songName: `Ajab Si <br><div class="subtitle">KK</div>`,
        poster: "img/14.jpeg",
    },
    {
        id: "15",
        songName: `I Wanna Be Yours <br><div class="subtitle">Arctic Monkeys</div>`,
        poster: "img/15.jpeg",
    },
    {
        id: "16",
        songName: `APT<br><div class="subtitle">Rose , Bruno Mars</div>`,
        poster: "img/16.jpeg",
    },
    {
        id: "17",
        songName: ` Mirror Ball <br><div class="subtitle"> Taylor Swift</div>`,
        poster: "img/17.jpeg",
    },
    {
        id: "18",
        songName: `Unwritten<br><div class="subtitle">Natasha Bedingfield</div>`,
        poster: "img/18.jpeg",
    },
    {
        id: "19",
        songName: `Ve Haniyaan <br><div class="subtitle">Avvy Sra , Danny , Sagar</div>`,
        poster: "img/19.jpeg",
    },
    {
        id: "20",
        songName: `Jab Koi Baat Bigad Jaye <br><div class="subtitle">Kumar Sanu</div>`,
        poster: "img/20.jpeg",
    }
]


Array.from(document.getElementsByClassName('songItem')).forEach((e, i) => {
    e.getElementsByTagName('img')[0].src = songs[i].poster;
    e.getElementsByTagName('h5')[0].innerHTML = songs[i].songName;

});




let masterPlay = document.getElementById('masterPlay');
let wave = document.getElementById('wave');

masterPlay.addEventListener('click', () => {
    if (music.paused || music.currentTime <= 0) {
        music.play();
        wave.classList.add('active1');
        masterPlay.classList.remove('bi-play-fill');
        masterPlay.classList.add('bi-pause-fill');
    } else {
        music.pause();
        wave.classList.remove('active1');
        masterPlay.classList.add('bi-play-fill');
        masterPlay.classList.remove('bi-pause-fill');
    }
});

const makeAllplays = () => {
    Array.from(document.getElementsByClassName('playListPlay')).forEach((el) => {
        el.classList.add('bi-play-circle-fill');
        el.classList.remove('bi-pause-circle-fill');
    })
}
const makeAllBackground = () => {
    Array.from(document.getElementsByClassName('songItem')).forEach((el) => {
        el.style.background = 'rgb(105, 105, 105, .0)';
    })
}

let index = 0;
let poster_master_play = document.getElementById('poster_master_play');
let download_music = document.getElementById('download_music');
let title = document.getElementById('title');
Array.from(document.getElementsByClassName('playListPlay')).forEach((e) => {
    e.addEventListener('click', (el) => {
        index = el.target.id;
        // console.log(index);
        music.src = `audio/${index}m.mp3`;
        poster_master_play.src = `img/${index}.jpeg`;
        music.play();
        masterPlay.classList.remove('bi-play-fill');
        masterPlay.classList.add('bi-pause-fill');
        download_music.href =  `audio/${index}m.mp3`;
        let songTitles = songs.filter((els) => {
            return els.id == index;
        });

        songTitles.forEach(elss => {
            let { songName } = elss;
            title.innerHTML = songName;
            download_music.setAttribute('download', songName);
        });

        makeAllBackground();
        Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
        makeAllplays();
        el.target.classList.remove('bi-play-circle-fill');
        el.target.classList.add('bi-pause-circle-fill');
        wave.classList.add('active1');
    });
})


let currentStart = document.getElementById('currentStart');
let currentEnd = document.getElementById('currentEnd');
let seek = document.getElementById('seek');
let bar2 = document.getElementById('bar2');
let dot = document.getElementsByClassName('dot')[0];

music.addEventListener('timeupdate', () => {
    let music_curr = music.currentTime;
    let music_dur = music.duration;

    let min1 = Math.floor(music_dur / 60);
    let sec1 = Math.floor(music_dur % 60);

    // console.log(min1);
    if (sec1 < 10) {
        sec1 = `0${sec1}`;
    }
    currentEnd.innerText = `${min1}:${sec1}`;

    let min2 = Math.floor(music_curr / 60);
    let sec2 = Math.floor(music_curr % 60);
    if (sec2 < 10) {
        sec2 = `0${sec2}`;
    }
    currentStart.innerText = `${min2}:${sec2}`;


    let progressBar = parseInt((music_curr / music_dur) * 100);
    seek.value = progressBar;
    // console.log(seek.value);
    let seekbar = seek.value;
    bar2.style.width = `${seekbar}%`;
    dot.style.left = `${seekbar}%`;
});

seek.addEventListener('change', () => {
    music.currentTime = seek.value * music.duration / 100;
});

let vol_icon = document.getElementById('vol_icon');
let vol = document.getElementById('vol');
let vol_bar = document.getElementsByClassName('vol_bar')[0];
let vol_dot = document.getElementById('vol_dot');

vol.addEventListener('change', () => {
    if (vol.value == 0) {
        vol_icon.classList.remove('bi-volume-up-fill');
        vol_icon.classList.remove('bi-volume-down-fill');
        vol_icon.classList.add('bi-volume-off-fill');
    }
    if (vol.value > 0) {
        vol_icon.classList.remove('bi-volume-up-fill');
        vol_icon.classList.add('bi-volume-down-fill');
        vol_icon.classList.remove('bi-volume-off-fill');
    }
    if (vol.value > 50) {
        vol_icon.classList.add('bi-volume-up-fill');
        vol_icon.classList.remove('bi-volume-down-fill');
        vol_icon.classList.remove('bi-volume-off-fill');
    }
    let vol_a = vol.value;
    vol_bar.style.width = `${vol_a}%`;
    vol_dot.style.left = `${vol_a}%`;
    music.volume = vol_a / 100;
});


let back = document.getElementById('back');
let next = document.getElementById('next');

back.addEventListener('click', () => {
    index -= 1;
    if (index < 1) {
        index = Array.from(document.getElementsByClassName('songItem')).length;
    }
    music.src = `audio/${index}m.mp3`;
    poster_master_play.src = `img/${index}.jpeg`;
    music.play();
    masterPlay.classList.remove('bi-play-fill');
    masterPlay.classList.add('bi-pause-fill');

    let songTitles = songs.filter((els) => {
        return els.id == index;
    });

    songTitles.forEach(elss => {
        let { songName } = elss;
        title.innerHTML = songName;
    });

    makeAllBackground();
    Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
    makeAllplays();
    el.target.classList.remove('bi-play-circle-fill');
    el.target.classList.add('bi-pause-circle-fill');
    wave.classList.add('active1');
})

next.addEventListener('click', () => {
    index++;
    if (index > Array.from(document.getElementsByClassName('songItem')).length) {
        index = 1;
    }
    music.src = `audio/${index}m.mp3`;
    poster_master_play.src = `img/${index}.jpeg`;
    music.play();
    masterPlay.classList.remove('bi-play-fill');
    masterPlay.classList.add('bi-pause-fill');

    let songTitles = songs.filter((els) => {
        return els.id == index;
    });

    songTitles.forEach(elss => {
        let { songName } = elss;
        title.innerHTML = songName;
    });

    makeAllBackground();
    Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
    makeAllplays();
    el.target.classList.remove('bi-play-circle-fill');
    el.target.classList.add('bi-pause-circle-fill');
    wave.classList.add('active1');
});


let pop_song_left = document.getElementById('pop_song_left');
let pop_song_right = document.getElementById('pop_song_right');
let pop_song = document.getElementsByClassName('pop_song')[0];


pop_song_right.addEventListener('click', () => {
    pop_song.scrollLeft += 330;
});
pop_song_left.addEventListener('click', () => {
    pop_song.scrollLeft -= 330;
});

let pop_art_left = document.getElementById('pop_art_left');
let pop_art_right = document.getElementById('pop_art_right');
let Artists_bx = document.getElementsByClassName('Artists_bx')[0];


pop_art_right.addEventListener('click', () => {
    Artists_bx.scrollLeft += 330;
});
pop_art_left.addEventListener('click', () => {
    Artists_bx.scrollLeft -= 330;
});


let shuffle = document.getElementsByClassName('shuffle')[0];

shuffle.addEventListener('click', ()=>{
    let a = shuffle.innerHTML;

    switch (a) {
        case "next":
            shuffle.classList.add('bi-arrow-repeat');
            shuffle.classList.remove('bi-music-note-beamed');
            shuffle.classList.remove('bi-shuffle');
            shuffle.innerHTML = 'repeat';
            break;
    
       case "repeat": 
       shuffle.classList.remove('bi-arrow-repeat');
            shuffle.classList.remove('bi-music-note-beamed');
            shuffle.classList.add('bi-shuffle');
            shuffle.innerHTML = 'random';
            break;
       case "random": 
       shuffle.classList.remove('bi-arrow-repeat');
            shuffle.classList.add('bi-music-note-beamed');
            shuffle.classList.remove('bi-shuffle');
            shuffle.innerHTML = 'next';
            break;
    }
});



const next_music = () => {
    if (index == songs.length) {
        index = 1
    } else {
        index++;
    }
    music.src = `audio/${index}m.mp3`;
    poster_master_play.src = `img/${index}.jpeg`;
    music.play();
    masterPlay.classList.remove('bi-play-fill');
    masterPlay.classList.add('bi-pause-fill');
    download_music.href =  `audio/${index}m.mp3`;
    let songTitles = songs.filter((els) => {
        return els.id == index;
    });

    songTitles.forEach(elss => {
        let { songName } = elss;
        title.innerHTML = songName;
        download_music.setAttribute('download', songName);
    });

    makeAllBackground();
    Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
    makeAllplays();
    el.target.classList.remove('bi-play-circle-fill');
    el.target.classList.add('bi-pause-circle-fill');
    wave.classList.add('active1');
}
const repeat_music = () => {
    index;
    music.src = `audio/${index}m.mp3`;
    poster_master_play.src = `img/${index}.jpeg`;
    music.play();
    masterPlay.classList.remove('bi-play-fill');
    masterPlay.classList.add('bi-pause-fill');
    download_music.href =  `audio/${index}m.mp3`;
    let songTitles = songs.filter((els) => {
        return els.id == index;
    });

    songTitles.forEach(elss => {
        let { songName } = elss;
        title.innerHTML = songName;
        download_music.setAttribute('download', songName);
    });

    makeAllBackground();
    Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
    makeAllplays();
    el.target.classList.remove('bi-play-circle-fill');
    el.target.classList.add('bi-pause-circle-fill');
    wave.classList.add('active1');
}

const random_music = () => {
    if (index == songs.length) {
        index = 1
    } else {
        index = Math.floor((Math.random() * songs.length) + 1);
    }
    music.src = `audio/${index}m.mp3`;
    poster_master_play.src = `img/${index}.jpeg`;
    music.play();
    masterPlay.classList.remove('bi-play-fill');
    masterPlay.classList.add('bi-pause-fill');
    download_music.href =  `audio/${index}m.mp3`;
    let songTitles = songs.filter((els) => {
        return els.id == index;
    });

    songTitles.forEach(elss => {
        let { songName } = elss;
        title.innerHTML = songName;
        download_music.setAttribute('download', songName);
    });

    makeAllBackground();
    Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
    makeAllplays();
    el.target.classList.remove('bi-play-circle-fill');
    el.target.classList.add('bi-pause-circle-fill');
    wave.classList.add('active1');
}



music.addEventListener('ended', ()=>{
    let b = shuffle.innerHTML;

    switch (b) {
        case 'repeat':
            repeat_music();
            break;
        case 'next':
            next_music();
            break;
        case 'random':
            random_music();
            break;
    }
})

// LAST LISTENING FUNCTIONALITY
let lastListeningList = document.getElementById("lastListeningList");
let lastPlayedSongs = [];

function addLastListening(song) {
    if (!lastPlayedSongs.includes(song.id)) {
        lastPlayedSongs.unshift(song.id);
        if (lastPlayedSongs.length > 5) lastPlayedSongs.pop(); // Keep only last 5
        updateLastListening();
    }
}

function updateLastListening() {
    lastListeningList.innerHTML = "";
    lastPlayedSongs.forEach(id => {
        let song = songs.find(s => s.id === id);
        if (song) {
            let listItem = document.createElement("li");
            listItem.innerHTML = `<img src="${song.poster}" alt="">
                                  <h5>${song.songName}</h5>`;
            lastListeningList.appendChild(listItem);
        }
    });
}

// RECOMMENDED SONGS FUNCTIONALITY
let recommendedList = document.getElementById("recommendedList");

function loadRecommended() {
    recommendedList.innerHTML = "";
    let shuffledSongs = [...songs].sort(() => Math.random() - 0.5).slice(0, 5);
    shuffledSongs.forEach(song => {
        let listItem = document.createElement("li");
        listItem.innerHTML = `<img src="${song.poster}" alt="">
                              <h5>${song.songName}</h5>`;
        recommendedList.appendChild(listItem);
    });
}

// MY LIBRARY FUNCTIONALITY
let myLibraryList = document.getElementById("myLibraryList");
let myLibrarySongs = [];

function addToLibrary(song) {
    if (!myLibrarySongs.includes(song.id)) {
        myLibrarySongs.push(song.id);
        updateMyLibrary();
    }
}

function updateMyLibrary() {
    myLibraryList.innerHTML = "";
    myLibrarySongs.forEach(id => {
        let song = songs.find(s => s.id === id);
        if (song) {
            let listItem = document.createElement("li");
            listItem.innerHTML = `<img src="${song.poster}" alt="">
                                  <h5>${song.songName}</h5>`;
            myLibraryList.appendChild(listItem);
        }
    });
}

// UPDATE LAST LISTENING & LIBRARY ON SONG PLAY
Array.from(document.getElementsByClassName("playListPlay")).forEach((e) => {
    e.addEventListener("click", (el) => {
        let index = el.target.id;
        let song = songs.find(s => s.id === index);
        if (song) {
            addLastListening(song);
            addToLibrary(song);
        }
    });
});

// LOAD RECOMMENDED SONGS ON PAGE LOAD
document.addEventListener("DOMContentLoaded", loadRecommended);

// Get the elements for updating song details
let currentSongImage = document.getElementById('currentSongImage');
let currentSongTitle = document.getElementById('currentSongTitle');
let currentSongArtist = document.getElementById('currentSongArtist');

// Update the event listener to change song details
Array.from(document.getElementsByClassName('playListPlay')).forEach((e) => {
    e.addEventListener('click', (el) => {
        let index = el.target.id;
        music.src = `audio/${index}m.mp3`;
        poster_master_play.src = `img/${index}.jpeg`;
        music.play();
        masterPlay.classList.replace('bi-play-fill', 'bi-pause-fill');
        wave.classList.add('active1');

        let songDetails = songs.find(song => song.id == index);
        if (songDetails) {
            let tempDiv = document.createElement("div");
            tempDiv.innerHTML = songDetails.songName; // Convert HTML to plain text

            let songName = tempDiv.childNodes[0].textContent.trim(); // Extract song name
            let artistName = tempDiv.querySelector(".subtitle").textContent.trim(); // Extract artist name

            currentSongTitle.innerText = songName;  // Update song name
            currentSongArtist.innerText = artistName; // Update artist name
            currentSongImage.src = `img/${index}.jpeg`; // Update song image
        }

        makeAllBackground();
        Array.from(document.getElementsByClassName('songItem'))[index - 1].style.background = "rgb(105, 105, 105, .1)";
        makeAllplays();
        el.target.classList.replace('bi-play-circle-fill', 'bi-pause-circle-fill');
    });
});





document.getElementById('search-input').addEventListener('keyup', function () {
    const query = this.value.toLowerCase();
    filterSongs(query);
});

function filterSongs(query) {
    const filteredSongs = songs.filter(song => 
        song.songName.toLowerCase().includes(query)
    );

    updateSearchResults(filteredSongs);
}

function updateSearchResults(filteredSongs) {
    const resultsContainer = document.querySelector('.search_results_modal');
    resultsContainer.innerHTML = '';

    if (filteredSongs.length === 0) {
        resultsContainer.innerHTML = '<p>No songs found</p>';
        return;
    }

    // Show the modal
    document.getElementById('searchModal').style.display = "block";

    filteredSongs.forEach(song => {
        let { id, songName, poster } = song;

        let card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <img src="${poster}" alt="">
            <div class="content">${songName}</div>
        `;

        card.addEventListener('click', () => playSong(id));
        resultsContainer.appendChild(card);
    });
}

// Function to play the song
function playSong(songId) {
    let song = songs.find(s => s.id === songId);
    if (song) {
        music.src = `audio/${songId}m.mp3`;
        poster_master_play.src = `img/${songId}.jpeg`;
        music.play();
        title.innerHTML = song.songName;
        masterPlay.classList.add('bi-pause-fill');
        masterPlay.classList.remove('bi-play-fill');
        wave.classList.add('active1');
        
        // Close the modal after playing the song
        document.getElementById('searchModal').style.display = "none";
    }
}

// Close the modal when the user clicks on <span> (x)
document.querySelector('.close').onclick = function() {
    document.getElementById('searchModal').style.display = "none";
}

// Close the modal when the user clicks anywhere outside of the modal
window.onclick = function(event) {
    const modal = document.getElementById('searchModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}







