// AngularJS App
var app = angular.module('musicApp', []);

app.controller('SignupController', ['$scope', '$http', function ($scope, $http) {
    $scope.user = {};
    $scope.signupError = false;
    $scope.signupSuccess = false;

    $scope.registerUser = function () {
        // Check if passwords match
        if ($scope.user.password !== $scope.user.confirmPassword) {
            $scope.signupError = true;
            $scope.signupErrorMessage = "Passwords do not match!";
            return;
        }

        // Send a POST request to the server
        $http.post('/signup', {
            fullName: $scope.user.fullName,
            email: $scope.user.email,
            password: $scope.user.password
        }).then(function (response) {
            // Handle success
            $scope.signupSuccess = true;
            $scope.signupSuccessMessage = response.data.message; // Use the success message from the server
            $scope.signupError = false;

            // Redirect to login page after a delay
            setTimeout(() => {
                window.location.href = "login.html"; // Redirect to login page
            }, 2000);
        }, function (error) {
            // Handle error properly
            $scope.signupError = true;
            $scope.signupErrorMessage = error.data.error || "An unexpected error occurred.";
            $scope.signupSuccess = false;
        });
    };
}]);

// Toggle Password Visibility
function togglePassword(fieldId) {
    var passwordField = document.getElementById(fieldId);
    passwordField.type = passwordField.type === "password" ? "text" : "password";
}
