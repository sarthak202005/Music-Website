var app = angular.module('musicApp', []);

app.controller('LoginController', function ($scope, $http) {
    $scope.user = {};
    $scope.loginError = false;

    $scope.validateLogin = function () {
        $http.post('http://localhost:5000/login', {
            email: $scope.user.email,
            password: $scope.user.password
        }).then(function (response) {
            localStorage.setItem('token', response.data.token);
            window.location.href = "index.html";
        }).catch(function (error) {
            $scope.loginError = true;
            $scope.loginErrorMessage = error.data.message;
        });
    };
});

// Toggle Password Visibility
function togglePassword() {
    var passwordField = document.getElementById('password');
    passwordField.type = passwordField.type === "password" ? "text" : "password";
}
