// AngularJS App
var app = angular.module('musicApp', []);

app.controller('LoginController', ['$scope', '$http', function ($scope, $http) {
    $scope.user = {};
    $scope.loginError = false;
    $scope.loginErrorMessage = "";

    $scope.validateLogin = function () {
        console.log("User email:", $scope.user.email); // Debugging
        console.log("User password:", $scope.user.password); // Debugging

        $http.post('/login', {
            email: $scope.user.email,  // ✅ Fixed to match the updated HTML
            password: $scope.user.password
        }).then(function (response) {
            alert('Login successful!');
            window.location.href = "index.html";
        }, function (error) {
            $scope.loginError = true;
            if (error.status === 401) {
                $scope.loginErrorMessage = "Invalid email or password.";
            } else {
                $scope.loginErrorMessage = error.data?.error || "An error occurred. Please try again.";
            }
        });
    };
}]);

// Toggle Password Visibility
function togglePassword(fieldId) {
    var passwordField = document.getElementById(fieldId);
    passwordField.type = passwordField.type === "password" ? "text" : "password";
}
