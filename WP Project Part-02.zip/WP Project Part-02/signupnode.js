var app = angular.module('musicApp', []);

app.controller('SignupController', function ($scope, $http) {
    $scope.user = {};
    $scope.signupError = false;
    $scope.signupSuccess = false;

    $scope.registerUser = function () {
        if ($scope.user.password !== $scope.user.confirmPassword) {
            $scope.signupError = true;
            $scope.signupErrorMessage = "Passwords do not match!";
            return;
        }

        $http.post('http://localhost:5000/signup', {
            fullName: $scope.user.fullName,
            email: $scope.user.email,
            password: $scope.user.password
        }).then(function (response) {
            $scope.signupSuccess = true;
            $scope.signupSuccessMessage = response.data.message;

            setTimeout(() => {
                window.location.href = "login.html";
            }, 2000);
        }).catch(function (error) {
            $scope.signupError = true;
            $scope.signupErrorMessage = error.data.message;
        });
    };
});

// Toggle Password Visibility
function togglePassword(fieldId) {
    var passwordField = document.getElementById(fieldId);
    passwordField.type = passwordField.type === "password" ? "text" : "password";
}
